const express = require("express");
//controllers
const chatRoom = require("../controllers/chatRoom.js");
const auth = require("../middlewares/auth.js");
const router = express.Router();

router
  .get("/", chatRoom.getRecentConversation)
  .get("/:roomId", chatRoom.getConversationByRoomId)
  .post("/initiate", auth.decode, chatRoom.initiate)
  .post("/:roomId/message", chatRoom.postMessage)
  .put("/:roomId/mark-read", chatRoom.markConversationReadyRoomId);

module.exports = router;
