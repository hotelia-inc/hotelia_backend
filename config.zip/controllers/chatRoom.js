const makeValidation = require("@withvoid/make-validation");
const { ChatRoomModel, CHAT_ROOM_TYPES } = require("../models/ChatRoom.js");

module.exports = {
  initiate: async (req, res) => {
    try {
      //We validate our data to make sure they conform to our Schema definition
      const validation = makeValidation((types) => ({
        payload: req.body,
        checks: {
          userIds: {
            type: types.array,
            options: { unique: true, empty: false, stringOnly: true },
          },
          type: { type: types.string }, //types.enum, options: { enum: CHAT_ROOM_TYPES } },
        },
      }));

      if (!validation.success) {
        return res.status(400).json({ ...validation });
      }

      const { userIds, type } = req.body;

      /*Note while our "userIds" and "type" care destructured from "req.body", 
      "userId" is made available by the decode function in our jwt.js file.
      -----Here's a snippet of the code -----
        const accessToken = req.headers.authorization.split(" ")[1];
        try {
          const decoded = jwt.verify(accessToken, SECRET_KEY);
          req.userId = decoded.userId;
          req.userType = dcoded.type;
          return next();
      -------End of snippet-----
      We attached it to the req object after deoding and extracting it from the token*/
      const { userId: chatInitiator } = req;
      const allUserIds = [...userIds, chatInitiator];
      const chatRoom = await ChatRoomModel.initiateChat(
        allUserIds,
        type,
        chatInitiator
      );
      return res.status(200).json({ success: true, chatRoom });
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  postMessage: async (req, res) => {
    try {
      const { roomId } = req.params;
      const validation = makeValidation((types) => ({
        payload: req.body,
        checks: {
          messageText: { type: types.string },
        },
      }));

      if (!validation.success) {
        return res.status(400).json({ ...validation });
      }

      const messagePayload = {
        messageText: req.body.messageText,
      };

      const currentLoggedUser = req.userId;
      const post = await ChatMessageModel.createPostInChatRoom(
        roomId,
        messagePayload,
        currentLoggedUser
      );
      global.io.sockets.in(roomId).emit("new message", { message: post });
      return res.status(200).json({ success: true, post });
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  getConversationByRoomId: async (req, res) => {
    try {
      const { roomId } = req.params;
      const room = await ChatRoomModel.getChatRoomByRoomId(roomId);
      if (!room) {
        return res.status(400).json({
          success: false,
          message: "No room exist for this id",
        });
      }
      const users = await UserModel.getUserByIds(room.UserIds);
      const options = {
        page: parseInt(req.query.page) || 0,
        limit: parseInt(req.query.limit) || 10,
      };
      const conversation = await ChatMessageModel.getConversationByRoomId(
        roomId,
        options
      );
      return res.status(200).json({
        success: true,
        conversation,
        users,
      });
    } catch (error) {
      return res.status(500).json({ success: false, error });
    }
  },
  markConversationReadyRoomId: async (req, res) => {
    try {
      const { roomId } = req.params;
      const room = await ChatRoomModel.getChatRoomByRoomId(roomid);
      if (!room) {
        return res.status(400).json({
          success: false,
          message: "No room exist for this id",
        });
      }

      const currentLoggedUser = req.userId;
      const result = await ChatMessageModel.markMessageRead(
        roomId,
        currentLoggedUser
      );
      return res.status(200).json({ success: true, data: result });
    } catch (error) {
      console.log(error);
      return res.status(500).json({ success: false, error });
    }
  },
  getRecentConversation: async (req, res) => {},
};
