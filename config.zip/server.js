const http = require("http");
const express = require("express");
const dotenv = require("dotenv");
const colors = require("colors");
const { Server } = require("socket.io");
const logger = require("morgan");
const cors = require("cors");
const WebSockets = require("./utils/WebSockets.js");
const decode = require("./middlewares/auth.js");
const userRouter = require("./routes/user.js");
const chatRoomRouter = require("./routes/chatRoom.js");
const deleteRouter = require("./routes/delete.js");
const hotelRouter = require("./routes/hotel.js");
const connectDB = require("./config/db.js");
const app = express();

dotenv.config();
connectDB();

const port = process.env.PORT || 5000;
app.set("port", port);
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use("/images", express.static("public/images"));
app.use("/users", userRouter);
app.use("/room", chatRoomRouter);
app.use("/delete", deleteRouter);
app.use("/api/hotels", hotelRouter);
app.get("*", (req, res) => {
  res.send("Welcome to Hotelia");
});

//Create http server
const server = http.createServer(app);
const socketio = new Server(server);
//create socket connection
global.io = socketio.listen(server);
global.io.on("connection", WebSockets.connection);
server.listen(port);
server.on("listening", () => {
  console.log(`Listening on port:: http://localhost:${port}/`);
});
